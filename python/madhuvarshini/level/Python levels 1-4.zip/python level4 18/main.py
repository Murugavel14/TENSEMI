sum = 0
for i in range (10, 100):
    if(i%2 != 0):
        sum += i
print(sum)