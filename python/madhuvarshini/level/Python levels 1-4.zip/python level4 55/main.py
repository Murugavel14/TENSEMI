def addition(a,b):
    return int(a) + int(b)
def subraction(a,b):
    return int(a)- int(b)
def multiplication(a,b):
    return int(a)*int(b)
def division (a,b):
    if int(b) == 0:
        print("EROR: Division by zero")
    quotient = int(a) // int(b)
    reminder = int(a) % int(b)
    return f"quotient = {quotient}, reminder = {reminder}"
print("calc")
a = input("Enter a number: ")
b = input("Enter a number: ")
if not a.isdigit() or not b.isdigit():
    print("INVALID")
else:
    calc = input("Choose the operator: +, -, *, / ==> ")
    if calc == "+":
        print("Addition", addition(a,b))
    elif calc == "-":
        print("Subraction" ,subracton(a,b))
    elif calc == "*":
        print("Multiplication", multiplication(a,b))
    elif calc == "/":
        if b == 0:
            print ("ERROR: Divison by zero")
        print("Division", division(a,b))
    else: print("Invalid Operator")